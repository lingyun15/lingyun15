// pages/baojiefuwu/baojiefuwu.js
var is_1_height;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index: 1,
    has_data: 1,
    status: false,
    scrollTop:200,
    list: [
      
    ],
    user:[
        
    ]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        wx.createSelectorQuery().select('video').boundingClientRect(function (rect) {
          var is_1_height = Number(rect.height) // 节点的宽度
          that.setData({
            height: Number(res.windowHeight) - is_1_height
          });
        }).exec();
      }
    });
  
  },
  submit: function () {
    this.setData({
      status: true
    })
  },
  close_shadow: function () {
    this.setData({
      status: false
    });
    this.get_hight()
  }, 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  get_selected: function (e) {
    var index = e.currentTarget.dataset.id;
    this.setData({
      index: index
    })
    console.log(e)
  },
  get_hight(){
    var ele = wx.createSelectorQuery();
    ele.select('.show_cart_list').boundingClientRect(function(exec){
      console.log(exec)
    });
  }
})