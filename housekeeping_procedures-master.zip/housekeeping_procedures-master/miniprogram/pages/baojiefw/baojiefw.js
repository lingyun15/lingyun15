var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    'iscart': false, //没有数据
    indexs: 1,
    has_data: 1,
    page: 1,
    status: false,
    statuss: false,
    totalPrice: 0,
    carlist: [],
    list: [],
    height: 'auto',
    type_id:0

  },
  home_page: function() {
    wx.navigateTo({
      url: '/pages/shouyeqt/shouyeqt',
    })
  },
  Customer_service: function() {
    wx.navigateTo({
      url: '/pages/kefu/kefu',
    })
  },
  get_about: function (state) {
    var that = this
    wx.showLoading({
       title: '加载中',
    })
   },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var id = options.id 
    var that = this;

    that.setData({
      SeriesId: options.id,
    })
  },
  grt_commod: function(typeid) {
    var that = this;
    app.Get(api.wxapp.GetCommodity, {
      commodityTypeId: typeid,
      page: 1,
      pageSize: 10,
    }, function(res) {
      if (res.Code == 200) {
        
        var carlist = that.data.carlist;
        var shop_list = res.Data;
        for (var i = 0; i < shop_list.length; i++) {
          for (var j = 0; j < carlist.length; j++) {
            if (shop_list[i]['Id'] == carlist[j]['CommodityId']) {
              shop_list[i]['Count'] = carlist[j]['ShopCount']
            }
          }
        }
        that.setData({
          list: shop_list
        })


      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  //计算总价
  get_money: function(data) {
    var that = this;
    var goodList = data;
    var totalCount = 0;
    var totalPrice = 0;
    for (var i = 0; i < goodList.length; i++) {
      var good = goodList[i];
      totalPrice += good.ShopCount * good.Price;
    }

    that.get_hight()
    that.setData({
      totalPrice: totalPrice
    })
  },
  //获取购物车
  submit: function() {
    var that = this;
    app.Get(api.wxapp.GetShopCart, {}, function(res) {
      if (res.Code == 200) {
        console.log(res)
        if (res.Data.length > 0) {
          that.get_money(res.Data)
        } else {
          that.setData({
            totalPrice: 0
          })
        }
        that.setData({
          carlist: res.Data,
          status: true,
        })
        that.get_hight()

        wx.hideLoading()
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  //下单
  close_shadow: function(e) {
    var that = this;
    that.setData({

      status: true,
    })
    app.Get(api.wxapp.GetShopCart, {}, function(res) {
      if (res.Code == 200) {
        console.log(res)
        if (res.Data.length <= 0) {
          wx.showToast({
            title: '请添加订单',
            icon: 'none',
            duration: 2000,
            mask: true
          })
          return false;
        }

        if (res.Data.length > 0) {
          that.get_money(res.Data)
          wx.navigateTo({
            url: '/pages/tijiaodd/tijiaodd'
          })
        }
        that.setData({
          carlist: res.Data,
        })
        that.get_hight();
        wx.hideLoading()
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })

  },
  //关闭实名认证

  close_shadowe: function() {
    this.setData({
      statuss: false,
    })
    this.onShow();
  },
  submite: function() {
    this.setData({
      statuss: false,
    })
    this.onShow();
  },
  //关闭购物车
  closed: function() {
    this.setData({
      status: false
    })
  },
  //立即认证
  submitd: function() {
    wx.navigateTo({
      url: '/pages/relname/relname',
    })
  },
 

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    var id = that.data.SeriesId;
    that.get_about('');
    that.submit();
    app.Get(api.wxapp.GetCommodityType, {
      commoditySeriesId: id
    }, function(res) {     
      if (res.Code == 200) {
        if (res.Data.List.length != 0) {
          that.grt_commod(res.Data.List[0]['Id'])
          that.data.type_id = res.Data.List[0]['Id']
        }
        if (res.Data.IsReal == true) {
          that.setData({
            statuss: false
          })
          that.setData({
            iscart: true
          })
        }
        wx.setNavigationBarTitle({
          title: res.Data.Name //页面标题为路由参数
        })
        that.setData({
          type_id: that.data.type_id,
          seriesame: res.Data.Name,
          seriesacou: res.Data.Content,
          seriesatel: res.Data.KFTel,
          seriesareal: res.Data.IsReal,
          seriesaimg: res.Data.Img,
          seriesailist: res.Data.List,
          status: false,
        })
        wx.hideLoading()
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  get_selected: function(e) {
    var that = this;
    var index = e.currentTarget.dataset.id;
    that.grt_commod(index)
    that.setData({
      indexs: index
    })
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    var that = this;
    var pages = that.data.page + 1
    that.setData({
      page: pages
    })
    var typeids = that.data.type_id
    app.Get(api.wxapp.GetCommodity, {
      page: pages,
      pageSize: 10,
      commodityTypeId: typeids
    }, function(res) {
      if (res.Code == 200) {
        var carlist = that.data.carlist;
        var shop_list = res.Data;
        for (var i = 0; i < shop_list.length; i++) {
          for (var j = 0; j < carlist.length; j++) {
            if (shop_list[i]['Id'] == carlist[j]['CommodityId']) {
              shop_list[i]['Count'] = carlist[j]['ShopCount']
            }
          }
        }
        var lists = that.data.list.concat(shop_list)
        that.setData({
          list: lists
        })
        
      } else {
        var msg = res.Msg
        wx.showToast({
          title: msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //加
  bindPlus: function(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    app.Post(api.wxapp.AddShopCart, {
      CommodityId: id,
      Type: 1,
    }, function(res) {
      if (res.Code == 200) {
        let list = that.data.list;
        let count = list[index].Count;
        count = count + 1;
        list[index].Count = count;
        // that.tong_ding(id,count);
        that.setData({
          list: list
        });
      } else if (res.Code == 404) {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })


  },
  //减
  bindMinus: function(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    let list = that.data.list;
    let counts = list[index].Count;
    if (counts <= 0) {
      return false;
    }
    app.Post(api.wxapp.AddShopCart, {
      CommodityId: id,
      Type: 2,
    }, function(res) {
      if (res.Code == 200) {
        let count = list[index].Count;
        count = count - 1;
        list[index].Count = count;
        // that.tong_ding(id, count);
        that.setData({
          list: list
        });
      } else if (res.Code == 404) {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  //购物车加
  carbindPlus: function(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    app.Post(api.wxapp.AddShopCart, {
      CommodityId: id,
      Type: 1,
    }, function(res) {
      if (res.Code == 200) {
        let list = that.data.carlist;
        let count = list[index].ShopCount;
        count = count + 1;
        list[index].ShopCount = count;
        that.get_money(list);
        that.tong_shop(id, count);
        that.setData({
          carlist: list
        });
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  //购物车减
  carbindMinus: function(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    app.Post(api.wxapp.AddShopCart, {
      CommodityId: id,
      Type: 2,
    }, function(res) {
      if (res.Code == 200) {
        let list = that.data.carlist;
        let count = list[index].ShopCount;
        count = count - 1;
        list[index].ShopCount = count;
        if (count == 0) {
          list.splice(index, 1)
        }
        that.get_money(list)
        that.tong_shop(id, count);
        that.setData({
          carlist: list
        });
      } else if (res.Code == 404) {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },


//同步 数据
tong_shop:function(shopid,count){
  var that = this;
  var shop_list = that.data.list
  for (var i = 0; i < shop_list.length;i++){
    if (shop_list[i]['Id'] == shopid){
      shop_list[i]['Count'] = count
    }
  }
  var new_list = shop_list;
  console.log(shopid);
  that.setData({
    list: new_list
  })
},
//订单详情数据同步
  tong_ding: function (shopid,count) {
    var that = this;
    var ding_list = that.data.carlist
    for (var i = 0; i < ding_list.length; i++) {
      if (ding_list[i]['CommodityId'] == shopid) {
        ding_list[i]['ShopCount'] = count
      }
    }
    var new_list = ding_list;
    console.log(shopid);
    that.setData({
      list: new_list
    })
  },


  get_hight() {
    var ele = wx.createSelectorQuery();
    var that = this;
    var heights = 0;
    ele.selectAll('.heji-tt').boundingClientRect(function(exec) {
      for (var i = 0; i < exec.length; i++) {
        heights += exec[i]['height']
      }
      if (heights > 125) {
        that.setData({
          height: 150
        })
      } else {
        that.setData({
          height: 'auto'
        })
      }
    });
    ele.exec();
  }
})