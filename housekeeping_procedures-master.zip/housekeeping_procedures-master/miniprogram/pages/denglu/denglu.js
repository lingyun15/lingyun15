var api = require('../../untils/util.js');
var app = getApp();
Page({
  data: {  
    maxTextLen:11,
  },

  zhuce:function(){
    wx.navigateTo({
      url: '/pages/zhuce/zhuce',
    })
  },
  wangji: function () {
    wx: wx.navigateTo({
      url: '/pages/wangjimm/wangjimm',
    })
  },
  submit:function(){
    wx.navigateTo({
      url: '/pages/zhucexy/zhucexy',
    })
  },
  
  formSubmit:function(e){
    var that = this;
    var Tel = e.detail.value.Tel;
    var Pwd = e.detail.value.Pwd;
    if (Tel == '') {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (Pwd == '') {
      wx.showToast({
        title: '请输入密码',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    app.Post(api.wxapp.Login, {
      Pwd: Pwd,
      Tel: Tel, 
      OpenId: wx.getStorageSync("UserOpenId")
    }, function (res) {
      // console.log(res.Data.Token);return;
      if (res.Code == 200) {
        var toke = res.Data.Token
        wx.setStorageSync('userToken',toke);
        wx.showToast({
          title: '登录成功',
          duration: 2000,
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/shouyeqt/shouyeqt'
          })
        }, 1500)
      }else{
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  }
})