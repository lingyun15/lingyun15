var api = require('../../untils/util.js');
var app = getApp();
Page({ 

  /**
   * 页面的初始数据
   */
  data: {
    maxlength:-1,
    zong_mo:0,
    CommodityDetailTwo:[],
      list:[
       
      ],
      total:[
        {
          total:"178.00" 
        },
      ],
  },
  get_about: function (state) {
    var that = this
    wx.showLoading({
      title: '加载中',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.get_about('');
    var id = options.id;
    var zong_mo = 0;
    app.Get(api.wxapp.OrderDetail, {
      id: id,
    }, function (res) {
      if (res.Code == 200) {
        var order_one = res.Data.CommodityDetailOne;
        for (var i = 0; i < order_one.length; i++){
           zong_mo += (order_one[i]['Price'] * order_one[i]['Count'])
        };
        that.setData({
          order_number: res.Data.Number,
          order_address: res.Data.UserAddressHelp,
          CommoditySeriesName: res.Data.CommoditySeriesName,
          StateName: res.Data.StateName,
          order_data:res.Data,
          zong_mo: zong_mo
        })
        wx.hideLoading()
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },

  //立即支付
  now_pay:function(){
    var that = this;
    var Number = that.data.order_number;
    app.Post(api.wxapp.CreatOrderOne, {
      Number: Number,
      Type:2
    }, function (res) {
      // console.log(res);return; 
      if (res.Code == 200) {
        wx.requestPayment(
          {
            'timeStamp': res.Data.timeStamp,
            'nonceStr': res.Data.nonceStr,
            'package': res.Data.package,
            'signType': res.Data.signType,
            'paySign': res.Data.paySign,
            success: function (ress) {
              if (ress.errMsg == 'requestPayment:fail cancel') {
                wx.showModal({
                  content: JSON.stringify(ress),
                });
              } else {
                wx.showToast({
                  title: '付款成功',
                  icon: 'success',
                  duration: 2000,
                  success: function () {
                    wx.navigateBack({
                      delta: 1
                    })
                  }
                });
              }
            },
            fail: function (res) {
              wx.navigateBack({
                delta: 1
              })
            },
            complete: function (res) {
              // wx.switchTab({
              //   url: '/pages/personalCentre/personalCentre'
              // })
            }
          })
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },
  //删除订单 
  dele_order:function(){
    var that= this;
    var order_id = that.data.order_data.Id
    wx.showModal({
      title: '提示',
      content: '您确定要取消订单吗',
      success(res) {
        if (res.confirm) {
          app.Get(api.wxapp.DetateOrder, {
            orderId: order_id,
          }, function (res) {
            if (res.Code == 200) {
              wx.showToast({
                title: '取消成功',
                icon: 'success',
                duration: 2000,
                success:function(){
                  wx.navigateBack({
                    delta: 1
                  })
                }
              })
            }
            else {
              wx.showToast({
                title: res.Msg,
                icon: 'none',
                duration: 2000,
              });
            }
          })
        } else if (res.cancel) {

        }
      }
    })
  }
})