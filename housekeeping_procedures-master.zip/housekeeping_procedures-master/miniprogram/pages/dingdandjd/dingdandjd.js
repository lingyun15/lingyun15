var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [ 
   
    ],
    zong_mo: 0,
  }, 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var id = options.id;
    var zong_mo = 0;
    app.Get(api.wxapp.OrderDetail, {
      id: id,
    }, function (res) {
      console.log(res)
      if (res.Code == 200) {
        var order_one = res.Data.CommodityDetailOne;
        for (var i = 0; i < order_one.length; i++) {
          zong_mo += (order_one[i]['Price'] * order_one[i]['Count'])
        };
        that.setData({
          order_number: res.Data.Number,
          order_address: res.Data.UserAddressHelp,
          CommoditySeriesName: res.Data.CommoditySeriesName,
          StateName: res.Data.StateName,
          order_data: res.Data,
          zong_mo: zong_mo
        })
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },

 
  submit:function(){
    wx.navigateTo({
      url: '/pages/kefu/kefu',
    })
  }
})