var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderId: '',
    list: [{
        id: 1,
        name: "油烟机清洗",
        price: "89.00",
        term: "4小时/次/人，含檫玻璃和保洁。为了保障服务人员的生命安全，其中高层玻璃住。。。",
        number: "1",
      },
      {
        id: 1,
        name: "油烟机清洗",
        price: "89.00",
        term: "4小时/次/人，含檫玻璃和保洁。为了保障服务人员的生命安全，其中高层玻璃住。。。",
        number: "1",
      },
    ],
    total: [{
      total: "178.00"
    }, ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    var id = options.id;
    var zong_mo = 0;
    app.Get(api.wxapp.OrderDetail, {
      id: id,
    }, function(res) {
      console.log(res)
      if (res.Code == 200) {
        var order_one = res.Data.CommodityDetailOne;
        for (var i = 0; i < order_one.length; i++) {
          zong_mo += (order_one[i]['Price'] * order_one[i]['Count'])
        };
        that.setData({
          order_number: res.Data.Number,
          order_address: res.Data.UserAddressHelp,
          CommoditySeriesName: res.Data.CommoditySeriesName,
          StateName: res.Data.StateName,
          order_data: res.Data,
          zong_mo: zong_mo,
          OrderId: res.Data.Id,
        })
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //延长服务
  renew_order: function() {
    var that = this
    var id = that.data.order_data.Id

    wx.navigateTo({
      url: '/pages/yanchang/yanchang?id=' + id,
    })

  },
  //验收服务
  submit: function() {
    var that = this;
    var orderId = that.data.OrderId;

    wx.showModal({
      title: '提示',
      content: '是否确定验收服务',
      success(res) {
        if (res.confirm) {
          app.Get(api.wxapp.ChangeOrderState, {
            orderId: orderId
          }, function (res) {
            if (res.Code == 200) {
              wx.showToast({
                title: '感谢您的支持!',
                icon: 'none',
                duration: 2000,
                success:function(){
                  setTimeout(function(){
                    wx.navigateTo({
                      url: '/pages/mydingdan/mydingdan',
                    })
                  },2000);
                }
              });
              
            } else {
              var msg = res.Msg;
              wx.showToast({
                title: msg,
                icon: 'none',
                duration: 2000,
              });
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
    


  }
})