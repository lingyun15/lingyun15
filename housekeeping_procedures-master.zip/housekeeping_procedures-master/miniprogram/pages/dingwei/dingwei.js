var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.get_list('')
  },
  get_list: function(name) {
    var that = this;
    var city_name = wx.getStorageSync('city');
    app.Get(api.wxapp.GetCityByProvinceId, {
      cityName: name
    }, function(res) {
      if (res.Code == 200) {
        that.setData({
          city_name: city_name,
          city_list: res.Data
        })
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    var city_name = wx.getStorageSync('city');
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  city_dian: function(e) {
    var name = e.currentTarget.dataset.name;
    wx.setStorageSync('city', name)
    wx.reLaunch({
      url:'../shouyeqt/shouyeqt'
    })
  },
  get_name: function() {
    console.log(11)
    var name = this.data.citynames
    if (name == '') {
      wx.showToast({
        title: '请输入城市名称',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    this.get_list(name)
  },
  city_name: function(e) {
    console.log(e)
    var cityname = e.detail.value
    this.setData({
      citynames: cityname
    })
  }
})