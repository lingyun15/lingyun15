var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {},

  shouji: function() {
    wx.navigateTo({
      url: '/pages/phone/phone',
    })
  },
  submit: function() {
    wx.reLaunch({
      url: '/pages/denglu/denglu',
    })
  },
  chooseimage: function() {
    var that = this;
    wx.chooseImage({
      success(ress) {
        const tempFilePaths = ress.tempFilePaths
        wx.uploadFile({
          url: api.wxapp.UploadFileNew, // 仅为示例，非真实的接口地址
          filePath: tempFilePaths[0],
          name: 'Img',
          success(res) {
            //console.log(res);return;
             var data = JSON.parse(res.data)
            if (res.statusCode == '200') {
              var token = wx.getStorageSync('userToken');
              var img = data.Data.fileWebPath[0];
              app.Get(api.wxapp.ChangeUserImg, {
                Img: img,
                token: token
              }, function(res) {
                if (res.Code == 200) {
                  that.setData({
                    tempFilePaths: data.Data.fileWebPath[0]
                  })
                } else {
                  wx.showToast({
                    title: res.Msg,
                    icon: 'none',
                    duration: 2000,
                  });
                }
              })
            }
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  // get_orderlist: function (state) {
  //   var that = this
  //   wx.showLoading({
  //     title: '加载中',
  //   })
  // },
  onShow: function() {
    var that = this;
    app.Get(api.wxapp.GetUserInfo, {}, function(res) {
      if (res.Code == 200) {
        console.log(res)
        that.setData({
          tempFilePaths: res.Data.Img,
          nickname: res.Data.Name,
          tel: res.Data.Tel,
          IsReal: res.Data.IsReal,
        })
        // wx.hideLoading()
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },
})