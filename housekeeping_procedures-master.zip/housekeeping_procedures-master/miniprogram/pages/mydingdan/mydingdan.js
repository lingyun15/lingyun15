var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据 
   */
  data: {
    iscart: false, //没有数据 
    selected: true,
    selected1: false,
    selected2: false,
    selected3: false,
    selected4: false,
    page: 1,
    items:[

    ]
    
  },
  onLoad: function () {
    // 调用函数时，传入new Date()参数，返回值是日期和时间
    var time = util.formatTime(new Date());
    // 再通过setData更改Page()里面的data，动态更新页面的数据
    this.setData({
      time: time
    });
  },


  /**
   * 生命周期函数--监听页面加载 
   */
  onLoad: function (options) {
    if (options.type == 0) {
      this.setData({
        selected: true
      })
    } else if (options.type == 1) {
      this.setData({
        selected1: true
      })
    } else if (options.type == 2) {
      this.setData({
        selected2: true
      })
    } else if (options.type == 3) {
      this.setData({
        selected3: true
      })
    } else if (options.type == 4) {
      this.setData({
        selected4: true
      })
    }
  },
  selected: function (e) {
    var type = e.currentTarget.dataset.type;
    this.setData({
      selected1: false,
      selected2: false,
      selected3: false,
      selected4: false,
      selected: true,
      type: type
    })
    this.get_orderlist('');
  },
  selected1: function (e) {
    var type = e.currentTarget.dataset.type;
    this.setData({
      selected: false,
      selected2: false,
      selected3: false,
      selected4: false,
      selected1: true,
      type: type
    })
    this.get_orderlist(type);
  },
  selected2: function (e) {
    var type = e.currentTarget.dataset.type;
    this.setData({
      selected: false,
      selected1: false,
      selected3: false,
      selected4: false,
      selected2: true,
      type: type
    })
    this.get_orderlist(type);
  },
  selected3: function (e) {
    var type = e.currentTarget.dataset.type;
    this.setData({
      selected: false,
      selected1: false,
      selected2: false,
      selected3: true,
      selected4: false,
      type: type
    })
    this.get_orderlist(type);
  },
  selected4: function (e) {
    var type = e.currentTarget.dataset.type;
    this.setData({
      selected: false,
      selected1: false,
      selected2: false,
      selected3: false,
      selected4: true,
      type:type
    })
    this.get_orderlist(type);
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    this.setData({
      selected1: false,
      selected2: false,
      selected3: false,
      selected4: false,
      selected: true
    })
    that.get_orderlist('');
  },
  get_orderlist: function (state){
  var that = this
    wx.showLoading({
      title: '加载中',
    })
  app.Get(api.wxapp.OrderList, { 
    page: 1,
    pageSize: 10,
    state: state
  }, function (res) {
    console.log(res)
    if (res.Code == 200) {
      if (res.Data.length == 0) {
        that.setData({
          iscart: true
        });
      }else{
        that.setData({
          iscart: false
        });
      }
      that.setData({
        items: res.Data
      })
      wx.hideLoading()
    }
    else {
      wx.showToast({
        title: res.Msg,
        icon: 'none',
        duration: 2000,
      });
    }
  })
},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var pages = that.data.page + 1
    that.setData({
      page: pages
    })
    var state = that.data.type
    app.Get(api.wxapp.OrderList, {
      page: pages,
      pageSize: 10,
      state:state
    }, function (res) {
      console.log(res)
      if (res.Code == 200) {
        var lists = that.data.items.concat(res.Data)
        that.setData({
          items: lists
        })
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //订单详情
  order_detail:function(e){
    console.log(e)
    var id = e.currentTarget.dataset.id
    var type = e.currentTarget.dataset.type
    if(type == 1){
      wx.navigateTo({
        url: '/pages/dingdandfk/dingdandfk?id=' + id,
      })
    } else if (type == 2) { 
      wx.navigateTo({
        url: '/pages/dingdandjd/dingdandjd?id=' + id,
      })
    } else if (type == 3) {
      wx.navigateTo({
        url: '/pages/dingdandfw/dingdandfw?id=' + id,
      }) 
    } else if (type == 4) {
      wx.navigateTo({
        url: '/pages/dingdanfuwuz/dingdanfuwuz?id=' + id,
      })
    } else if (type == 6) {
      wx.navigateTo({
        url: '/pages/dingdanywc/dingdanywc?id=' + id,
      })
    } else if (type == 5) {
      wx.navigateTo({
        url: '/pages/dingdanyc/dingdanyc?id=' + id,
      })
    }else if(type == 7){
      wx.navigateTo({
        url: '/pages/dingdanyitui/dingdanyitui?id=' +id,
      })
    }
  }
})