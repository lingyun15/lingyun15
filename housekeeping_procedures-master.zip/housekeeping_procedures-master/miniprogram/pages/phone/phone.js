var api = require('../../untils/util.js');
var app = getApp();
Page({

    /** 
     * 页面的初始数据
     */
    data: { 
        phone:""
    },
    submit:function(){
        wx.navigateTo({
          url: '/pages/login/login',
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    get_userinfo:function(state){
        var that = this
        wx.showLoading({
          title:'加载中'
        })
    },
    onShow: function () { 
      var that = this;
      that.get_userinfo('');
      app.Get(api.wxapp.GetUserInfo, {
      }, function (res) {
        if (res.Code == 200) {
          var Img = (res.Data.Img)
            that.setData({
            tempFilePaths: Img,
            nickname: res.Data.Name,
            tel: res.Data.Tel
          })
          wx.hideLoading()
        }
        console.log(res); return;
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });

      })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
  //提交表单
  fromSubmit: function (e) {
    var that = this;
    var OldTel = e.detail.value.OldTel;
    var NewTel = e.detail.value.NewTel;
    var NewTelCode = e.detail.value.NewTelCode;
   
    if (NewTel == '') {
      wx.showToast({
        title: '请输入新手机号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (NewTelCode == '') {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none',
        duration: 2000, 
        mask: true
      })
      return false;
    }
   
    app.Post(api.wxapp.ChangeUserTel, {
      OldTel: OldTel,
      NewTel: NewTel,
      NewTelCode: NewTelCode,
    }, function (res) {
      if (res.Code == 200) {
        var toke = res.Data.Token
        wx.setStorageSync('userToken', toke);
        wx.reLaunch({
          url: '/pages/login/login',
        })
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }

    })

  },
  //发送验证码
  typenumber: function () {
    var that = this;
    var phone = that.data.phone;
    if (phone == '') {
      wx.showToast({
        title: '请输入新手机号',
        icon: 'none',
        duration: 2000, 
        mask: true
      })
      return false;
    }
    app.Get(api.wxapp.Sms, {
      tel: phone,
    }, function (res) {
      
      wx.showToast({
        title: res.Msg,
        icon: 'none',
        duration: 2000,
      });

    })
  },
  see_phone: function (e) {
    var that = this;
    that.setData({
      phone: e.detail.value
    })
  },
  checkboxChange: function (e) {
    var that = this;
    var chec_type = that.data.checkbox;
    if (chec_type == 1) {
      that.setData({
        checkbox: 2
      })
    } else {
      that.setData({
        checkbox: 1
      })
    }
  }
})