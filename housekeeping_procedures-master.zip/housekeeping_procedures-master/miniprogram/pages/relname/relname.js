var api = require('../../untils/util.js');
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */

  data: {
    status: false,
    upload_identity_1: '/images/zheng.png',
    upload_identity_2: '/images/fan.png',
    upload_identity_3: '/images/shou.png',
    upload_identity_4: '/images/geren.png',
    CardImg1: '',
    CardImg2: '',
    CardImg3: '',
    CardImg4: '',
    maxLength:18,
  },

  /** 
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  submit: function(e) {
    var that = this;
    var RealName = e.detail.RealName;
    var Sex = that.data.Sex;
    var Card = e.detail.Card;
    var CardImg1 = that.data.CardImg1;
    var CardImg2 = that.data.CardImg2;
    var CardImg3 = that.data.CardImg3;
    var CardImg4 = that.data.CardImg4;
    var Code = e.detail.Code;
    if (RealName == '') {
      wx.showToast({
        title: '请输入真实姓名',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (Sex == "") {
      wx.showToast({
        title: '请选择性别',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (Card == '') {
      wx.showToast({
        title: '请输入身份证号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg1 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg2 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg3 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg4 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    app.Post(api.wxapp.ChangeUserReal, {
      RealNamed: RealName,
      Sex: Sex,
      Card: Card,
      CardImg1: CardImg1,
      CardImg2: CardImg2,
      CardImg3: CardImg3,
      CardImg4: CardImg4,
    }, function(res) {
      if (res.Code == 200) {
        var toke = res.Data.Token
        wx.setStorageSync('userToken', toke);
        this.setData({
          status: true,
        })
      } else {
        var msg = res.Msg
        wx.showToast({
          title: msg,
          icon: 'none',
          duration: 2000,
        });
      }

    })
  },
  close_shadow: function() {
    wx.navigateTo({
      url: '/pages/login/login',
    })
    this.onShow();
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    app.Get(api.wxapp.GetChangeUserReal, {}, function(res) {
      console.log(res.Data);
      if (res.Code == 200) {
        var info = res.Data;
        var imgs = info.CardImg.split(',');

        that.setData({
          info: res.Data,
          upload_identity_1: imgs[0],
          upload_identity_2: imgs[1],
          upload_identity_3: imgs[2],
          upload_identity_4: imgs[3],
          CardImg1: imgs[0],
          CardImg2: imgs[1],
          CardImg3: imgs[2],
          CardImg4: imgs[3],
        })
      } else if (res.Code == 400) {
        that.setData({
          info: ''
        })
      }

      //获取用户的审核状态
      app.Get(api.wxapp.GetUserInfo, {}, function(res) {
        if (res.Code == 200) {

          that.setData({
            IsReal: res.Data.IsReal,
          })
        }
      })
    })
  },
  upload_identity: function(e) {
    var type = e.currentTarget.dataset.type;
    var that = this;
    that.upload(type);
  },
  //提交表单
  reg: function(e) {
    var that = this;
    var RealName = e.detail.value.RealName;
    var Sex = that.data.Sex;
    var Card = e.detail.value.Card;
    var CardImg1 = that.data.CardImg1;
    var CardImg2 = that.data.CardImg2;
    var CardImg3 = that.data.CardImg3;
    var CardImg4 = that.data.CardImg4;
    if (RealName == '') {
      wx.showToast({
        title: '请输入真实姓名',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (Sex == "") {
      wx.showToast({
        title: '请选择性别',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (Card == '') {
      wx.showToast({
        title: '请输入身份证号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg1 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg2 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg3 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CardImg4 == "") {
      wx.showToast({
        title: '请上传身份证照片',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    var CardImgs = CardImg1 + ',' + CardImg2 + ',' + CardImg3 + ',' + CardImg4
    app.Post(api.wxapp.ChangeUserReal, {
      RealName: RealName,
      Sex: Sex,
      Card: Card,
      CardImg: CardImgs
    }, function(res) {
      if (res.Code == 200) {
        that.setData({
          status: true,
        })
      } else {
        var msg = res.Msg
        wx.showToast({
          title: msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },
  upload: function(type) {
    var that = this;
    wx.chooseImage({
      success(ress) {
        const tempFilePaths = ress.tempFilePaths
        wx.uploadFile({
          url: api.wxapp.UploadFileNew, // 仅为示例，非真实的接口地址
          filePath: tempFilePaths[0],
          name: 'Img',
          success(res) {
            var data = JSON.parse(res.data)
            console.log(data.Data.fileWebPath);
            console.log(data);
            console.log(222);
            if (res.statusCode == '200') {
              if (type == 1) {
                that.setData({
                  upload_identity_1: data.Data.fileWebPath,
                  CardImg1: data.Data.fileWebPath
                })
              } else if (type == 2) {
                that.setData({
                  upload_identity_2: data.Data.fileWebPath,
                  CardImg2: data.Data.fileWebPath
                })
              } else if (type == 3) {
                that.setData({
                  upload_identity_3: data.Data.fileWebPath,
                  CardImg3: data.Data.fileWebPath
                })
              } else if (type == 4) {
                that.setData({
                  upload_identity_4: data.Data.fileWebPath,
                  CardImg4: data.Data.fileWebPath
                })
              }
            }
          }
        })
      }
    })
  },
  select_sex: function(e) {
    var that = this;
    that.setData({
      Sex: e.detail.value
    })
  }
})