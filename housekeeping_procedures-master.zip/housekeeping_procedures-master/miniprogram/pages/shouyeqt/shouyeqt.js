var api = require('../../untils/util.js');
var app = getApp();
var wxMarkerData = [];
// 引用百度地图微信小程序JSAPI模块 
var bmap = require('../../untils/bmap-wx.min.js');
Page({
  data: {
    markers: [],
    latitude: '',
    longitude: '',
    rgcData: {},
    'iscart': false,
    series: [],
    indexs: 1,
    has_data: 1,
    markers: '',
    polyline: [{
      points: [{
          longitude: 119.95,
          latitude: 31.78,
        },
        {
          longitude: 119.95,
          latitude: 31.78,
        }
      ],
      color: '#FF0000DD',
      width: 2,
      dottedLine: true
    }],
    controls: [{
      id: 1,
      iconPath: '/resources/location.png',
      position: {
        left: 0,
        top: 300 - 50,
        width: 50,
        height: 50
      },
      clickable: true
    }],
    city_name: '定位中'
  },
  regionchange(e) {
    // console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  },
  dingwei: function() {
    wx.navigateTo({
      url: '/pages/dingwei/dingwei',
    })
  },
  geren: function() {
    wx.navigateTo({
      url: '/pages/login/login',
    })
  },
  dingdan: function() {
    wx.navigateTo({
      url: '/pages/mydingdan/mydingdan',
    })
  },
  /** 
   * 页面的初始数据
   */
  useImoocLogin: function(e) {
    app.get_user_info(e, function(res) {
      var info = wx.getStorageSync("userInfo")
      console.log(info)
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    app.Get(api.wxapp.GetUserInfo, {
    }, function(res) {
      console.log(res)
      if (res.Code == 200) {
        that.setData({
          series: res.Data
        })
      } else if (res.Code == 404) {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
          complete: complete
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    that.get_location();
  },
  get_selected: function(e) {
    var index = e.currentTarget.dataset.id;
    this.setData({
      indexs: index
    })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },
  makertap: function(e) {
    var that = this;
    var id = e.markerId;
  },
  get_location() {
    var that = this;
    wx.getLocation({
      type: 'gcj02', // 返回可以用于wx.openLocation的经纬度
      success(res) {
        const latitude = res.latitude
        const longitude = res.longitude
        that.setData({
          latitude: latitude,
          longitude: longitude
        });
        var resp = that.qqMapTransBMap(longitude, latitude);
        console.log(resp)
        var city_name = wx.getStorageSync('city');
        if (city_name) {
          app.Get(api.wxapp.GetCommoditySeries, {
            name: city_name
          }, function(resp) {
            console.log(resp)
            if (resp.Code == 200) {
              if (resp.Data.length != 0) {
                var indexs = resp.Data[0]['Id'];
                var iscart = true
              } else {
                var indexs = 0
                var iscart = false
              }
              that.setData({
                series: resp.Data,
                indexs: indexs
              });
              that.get_shop_list(city_name);
              that.setData({
                iscart: iscart
              })
              wx.hideLoading()

              that.setData({
                city_name: city_name
              })
            } else {
              wx.showToast({
                title: resp.Msg,
                icon: 'success',
                duration: 2000,
              });
            }
          })
        } else {
          app.Get(api.wxapp.GetCityName, {
            lng: resp.lng,
            lat: resp.lat
          }, function(res) {
            if (res.Code == 200) {
              wx.setStorageSync('city', res.Data);
              that.setData({
                city_name: res.Data
              })
              app.Get(api.wxapp.GetCommoditySeries, {
                name: res.Data
              }, function(resp) {
                if (resp.Code == 200) {
                  that.setData({
                    series: resp.Data
                  });
                  that.get_shop_list(res.Data);
                  that.setData({
                    iscart: true
                  })
                  wx.hideLoading()
                } else {
                  wx.showToast({
                    title: resp.Msg,
                    icon: 'success',
                    duration: 2000,
                  });
                }
              })
            }

          })
        }

      }
    })
  },
  //将腾讯地图转为百度地图
  qqMapTransBMap(lng, lat) {
    let x_pi = 3.14159265358979324 * 3000.0 / 180.0;
    let x = lng;
    let y = lat;
    let z = Math.sqrt(x * x + y * y) + 0.00002 * Math.sin(y * x_pi);
    let theta = Math.atan2(y, x) + 0.000003 * Math.cos(x * x_pi);
    let lngs = z * Math.cos(theta) + 0.0065;
    let lats = z * Math.sin(theta) + 0.006;

    return {
      lng: lngs,
      lat: lats
    }
  },
  //将百度地图转换为腾讯地图
  bMapTransQQMap(lng, lat) {
    let x_pi = 3.14159265358979324 * 3000.0 / 180.0;
    let x = lng - 0.0065;
    let y = lat - 0.006;
    let z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_pi);
    let theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_pi);
    let lngs = z * Math.cos(theta);
    let lats = z * Math.sin(theta);

    return {
      lng: lngs,
      lat: lats
    }
  },
  //获取商家列表
  get_shop_list(cityname) {
    var that = this;
    app.Get(api.wxapp.GetShopList, {
      cityName: cityname
    }, function(ress) {
      if (ress.Code == 200) {
        if (ress.Data != '') {
          var shops_lists = ress.Data;
          var mark_arr = [];
          for (var i = 0; i < shops_lists.length; i++) {
            var tran_addr = that.bMapTransQQMap(shops_lists[i]['Lng'], shops_lists[i]['Lat']);
            var obj = {};
            obj.iconPath = '/images/dibiao.png';
            obj.latitude = tran_addr.lat;
            obj.longitude = tran_addr.lng;
            obj.width = 15;
            obj.height = 20;
            mark_arr.push(obj);
          }
          console.log(mark_arr)
          that.setData({
            markers: mark_arr
          })
        }
      } else {
        wx.showToast({
          title: ress.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  submit: function() {
    var that = this;
    var index = that.data.indexs
    wx.navigateTo({
      url: '/pages/baojiefw/baojiefw?id=' + index,
    })
  }
})