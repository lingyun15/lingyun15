var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    'iscart': false, //没有数据
    catList: [],
    UserAddress: false,
    UserAddressId: '',
    totalPrice: 0,



  },
  get_about: function(state) {
    var that = this
    wx.showLoading({
      title: '加载中',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */

  onShow: function() {
    var that = this;
    that.get_about('');
    app.Get(api.wxapp.GetShopCart, {}, function(res) {
      if (res.Code == 200) {
        var ids = '';
        var goodList = res.Data;
        for (var i = 0; i < goodList.length; i++) {
          var good = goodList[i];
          ids += good.Id + ',';
        }
        var goodids = ids.substr(0, ids.length - 1)
        app.Get(api.wxapp.OrderShop, {
          ShopCartIds: goodids
        }, function(res) {
          if (res.Code == 200) {
            // console.log(res)
            var goos_list = res.Data.List;
            var CreateOrderDetail = []
            for (var i = 0; i < goos_list.length; i++) {
              var ceshi = {};
              var car_ids = [];
              var caridlist = goos_list[i].Detail;
              for (var j = 0; j < caridlist.length; j++) {
                var car_ids = car_ids.concat(caridlist[j].Id)
              }
              goos_list[i].ShopCartId = car_ids;
              ceshi.ShopSeriesId = goos_list[i].CommoditySeriesId;
              ceshi.ShopCartId = goos_list[i].ShopCartId;
              ceshi.Remark = '';
              CreateOrderDetail[i] = ceshi
            }
            that.get_money(goos_list);
            if (res.Data.UserAddress != null) {
              that.setData({
                UserAddress: true,
                add_list: res.Data.UserAddress,
                UserAddressId: res.Data.UserAddress.Id,
              })
            }
            that.setData({
              catList: res.Data.List,
              CreateOrderDetail: CreateOrderDetail
            })
            that.setData({
              iscart: true
            })
            wx.hideLoading()
          }
        })
      }
    })
  },

  manage: function() {
    wx.setStorageSync('sign', 1)
    wx.navigateTo({
      url: '/pages/xuanzedz/xuanzedz',
    })
  },
  
  //提交订单
  submit: function() {
    var that = this;
    var UserAddressId = that.data.UserAddressId
    var CreateOrderDetail = that.data.CreateOrderDetail;
    console.log(CreateOrderDetail)
    if (UserAddressId == '') {
      wx.showToast({
        title: '请选择地址',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    var data = {};
    data.CreateOrderDetail = CreateOrderDetail;
    data.UserAddressId = UserAddressId;
    data.Type = 2;
    app.Post(api.wxapp.CreatOrder, data, function(res) {
      if (res.Code == 200) {
        wx.requestPayment({
          'timeStamp': res.Data.timeStamp,
          'nonceStr': res.Data.nonceStr,
          'package': res.Data.package,
          'signType': res.Data.signType,
          'paySign': res.Data.paySign,
          success: function(ress) {
            if (ress.errMsg == 'requestPayment:fail cancel') {
              wx.showModal({
                content: JSON.stringify(ress),
              });
            } else {
              wx.showToast({
                title: '付款成功',
                icon: 'success',
                duration: 2000,
                success: function() {
                  wx.redirectTo({
                    url: '/pages/mydingdan/mydingdan'
                  })
                }
              });
            }
          },
          fail: function(res) {
            // wx.redirectTo({
            //   url: '/pages/mydingdan/mydingdan'
            // })
          },
          complete: function(res) {
            // wx.switchTab({
            //   url: '/pages/personalCentre/personalCentre'
            // })
          }
        })
      } else {
        var msg = res.Msg
        wx.showToast({
          title: msg,
          icon: 'none',
          duration: 2000,
        });
      }

    })
  },
  ceshi: function(e) {
    var that = this;
    console.log(e)
    var typeid = e.target.dataset.id;
    var count = e.detail.value
    var datas = that.data.CreateOrderDetail
    for (var i = 0; i < datas.length; i++) {
      if (datas[i]['ShopSeriesId'] == typeid) {
        datas[i]['Remark'] = count
      }
    }
    that.setData({
      CreateOrderDetail: datas
    })
  },
  //计算总价
  get_money: function(data) {
    var that = this;
    var goodList = data;
    var totalCount = 0;
    var totalPrice = 0;
    for (var i = 0; i < goodList.length; i++) {
      var good = goodList[i];
      totalPrice += good.Amount;
    }
    that.setData({
      totalPrice: totalPrice
    })
  },
})