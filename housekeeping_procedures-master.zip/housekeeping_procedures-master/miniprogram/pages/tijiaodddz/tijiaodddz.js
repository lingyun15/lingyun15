// pages/tijiaodddz/tijiaodddz.js
Page({

  /**
   * 页面的初始数据 
   */
  data: {
    list: [
      
    ],
    total: [
      
    ],
    user: [
     
    ],
    tota: [
      
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  //   console.log(options)
  
  //   app.Post(api.wxapp.CreatOrder, {
  //   }, function (res) {
  //     console.log(res)
  //     if (res.Code == 200) {
  //       // that.grt_commod(res.Data.List[0].Id)
  //       that.setData({
  //         UserAddressId: res.Data.UserAddressId,
  //         CreateOrderDetail: res.Data.CreateOrderDetail,
  //         Type: res.Data.Type,
  //       })
  //     }
  //     else {
  //       wx.showToast({
  //         title: res.Msg,
  //         icon: 'success',
  //         duration: 2000,
  //       });
  //     }
  //   })
  // },
  // grt_commod: function (typeid) {
  //   var that = this;
  //   app.Get(api.wxapp.GetCommodity, {
  //     commodityTypeId: typeid,
  //     page: 1,
  //   }, function (res) {
  //     console.log(res)
  //     if (res.Code == 200) {
  //       that.setData({
  //         list: res.Data
  //       })
  //     }
  //     else {
  //       wx.showToast({
  //         title: res.Msg,
  //         icon: 'success',
  //         duration: 2000,
  //       });
  //     }
  //   })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})