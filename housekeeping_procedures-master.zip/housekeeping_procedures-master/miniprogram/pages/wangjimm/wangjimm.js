var api = require('../../untils/util.js');
var app = getApp();
Page({ 

  /**
   * 页面的初始数据
   */
  data: {
    TextLen: 6,
    maxTextLen: 11,
      phone:'',
    currentTime: 60,
    send_sms:0,
    send_msg:'获取验证码'
  },
  denglu: function () {
    wx: wx.navigateTo({
      url: '/pages/denglu/denglu',
    })
  },
  zhuce: function () {
    wx: wx.navigateTo({
      url: '/pages/zhuce/zhuce',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //提交表单
  formSubmit: function (e) {
    var that = this;
    var Tel = e.detail.value.Tel;
    var Pwd = e.detail.value.Pwd;
    var YZM = e.detail.value.YZM;
    if (Tel == '') {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (YZM == '') {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (Pwd == '') {
      wx.showToast({
        title: '请输入密码',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    app.Post(api.wxapp.UserReset, {
      Pwd: Pwd,
      Tel: Tel,
      YZM: YZM,
    }, function (res) {
      if (res.Code == 200) { 
        var toke = res.Data.Token
        wx.setStorageSync('userToken', toke);
      setTimeout(function(){
        wx.reLaunch({
          url: '/pages/denglu/denglu'
        })
      },1500)
        wx.showToast({
          title: '修改成功', 
          duration: 2000,
        })
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
      })
  },
  //发送验证码
  typenumber: function () {
    var that = this;
    var phone = that.data.phone;
    var currentTime = that.data.currentTime;
    if (phone == '') {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    var t = setInterval(function () {
        currentTime--;
        that.setData({
          send_msg: currentTime + 's',
          send_sms:1
        })
        if (currentTime <= 0) {
          clearInterval(t)
          that.setData({
            time: '',
            currentTime: 60,
            send_sms: 0,
            send_msg: '获取验证码',
          })
        }
      }, 1000)
   
    app.Get(api.wxapp.Sms, {
      tel: phone,
    }, function (res) {
      wx.showToast({
        title: res.Msg,
        icon: 'none',
        duration: 2000,
      });

    })
  },
  see_phone: function (e) {
    var that = this;
    that.setData({
      phone: e.detail.value
    })
  }
})