var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index: 0,  
    arrays: [],
    CityOne: '',
    CityTwo: '',
    CityThree: '',
    CityIdOne: '',
    CityIdTwo: '',
    CityIdThree: '',
    IsDefault: false,
    addressdata: [],
    id:0,
    maxlength:11
  },
  get_about: function (state) {
    var that = this
    wx.showLoading({
      title: '加载中',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    this.setData({
      id: options.id
    })
    if (options.id == 0) {
      wx.setNavigationBarTitle({
        title: '添加地址'
      })
    } else {
      app.Get(api.wxapp.GetUserAddress, {
        id: options.id
      }, function (res) {
        console.log(res);
        if (res.Code == 200) {
          that.setData({
            address: res.Data,
            IsDefault: res.Data.IsDefault,
            CityIdOne: res.Data.CityIdOne,
            CityIdTwo: res.Data.CityIdTwo,
            CityIdThree: res.Data.CityIdThree,
          })
          /**请求省 */
          var arraysssss = [];
          var onezhong = 0
          app.Get(api.wxapp.GetProvince, {
          }, function (resone) {
            if (resone.Code == 200) {
              for (var i = 0; i < resone.Data.length; i++) {
                arraysssss.push(resone.Data[i].Name)
                if (resone.Data[i].Id == res.Data.CityIdOne) {
                  onezhong = i
                }
              }
              that.setData({
                CityOne: resone.Data,
                arrays: arraysssss,
                index: onezhong
              })
            }
            else {
              wx.showToast({
                title: res.Msg,
                icon: 'success',
                duration: 2000,
              });
            }
          })
          /******请求市 */
          var arrayss = [];
          var xuanzhong = 0;
          app.Get(api.wxapp.GetCityByProvinceId, {
            ProvinceId: res.Data.CityIdOne
          }, function (resss) {
            if (resss.Code == 200) {
              for (var i = 0; i < resss.Data.length; i++) {
                arrayss.push(resss.Data[i].Name)
                if (resss.Data[i].Id == that.data.CityIdTwo) {
                  xuanzhong = i
                }
              }
              that.setData({
                CityTwo: resss.Data,
                twoarrays: arrayss,
                towindex: xuanzhong,
              })
            }
            else {
              wx.showToast({
                title: res.Msg,
                icon: 'success',
                duration: 2000,
              });
            }
          })
          /****请求区 */
          var arraysss = [];
          var quzhong = 0
          app.Get(api.wxapp.GetAreaByCityId, {
            CityId: res.Data.CityIdTwo
          }, function (ress) {
            // console.log(that.data.CityIdThree);return;
            if (ress.Code == 200) {
              for (var ii = 0; ii < ress.Data.length; ii++) {
                arraysss.push(ress.Data[ii].Name)
                if (ress.Data[ii].Id == that.data.CityIdThree) {
                  quzhong = ii
                }
              }
              that.setData({
                CityThree: ress.Data,
                threearrays: arraysss,
                threeindex: quzhong,
              })
              // console.log(that.data.threearrays);
            }
            else {
              wx.showToast({
                title: ress.Msg,
                icon: 'success',
                duration: 2000,
              });
            }
          })

        }
        else {
          wx.showToast({
            title: res.Msg,
            icon: 'success',
            duration: 2000,
          });
        }
      })
      wx.setNavigationBarTitle({
        title: '编辑地址'
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var arrayss = [];
    that.get_about('');
    app.Get(api.wxapp.GetProvince, {
    }, function (res) {
      console.log(res);
      if (res.Code == 200) {
        for (var i = 0; i < res.Data.length; i++) {
          arrayss.push(res.Data[i].Name)
        }
        that.setData({
          CityOne: res.Data,
          arrays: arrayss
        })
        wx.hideLoading()
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  bindPickerChange(e) {
    var that = this;
    var inx = e.detail.value
    var citid = that.data.CityOne[inx].Id
    var arrayss = [];
    if (citid == 0) {
      return false;
    }
    app.Get(api.wxapp.GetCityByProvinceId, {
      ProvinceId: citid
    }, function (res) {
      if (res.Code == 200) {
        for (var i = 0; i < res.Data.length; i++) {
          arrayss.push(res.Data[i].Name)
        }
        that.setData({
          CityTwo: res.Data,
          twoarrays: arrayss,
          CityIdOne: citid,
          index: e.detail.value,
          towindex: 0
        })
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  bindPickerChangetow(e) {
    var that = this;
    var inx = e.detail.value
    var citytow = this.data.CityTwo[inx].Id
    var arrayss = [];
    if (citytow == 0) {
      return false;
    }
    app.Get(api.wxapp.GetAreaByCityId, {
      CityId: citytow
    }, function (res) {
      if (res.Code == 200) {
        for (var i = 0; i < res.Data.length; i++) {
          arrayss.push(res.Data[i].Name)
        }
        that.setData({
          CityThree: res.Data,
          threearrays: arrayss,
          CityIdTwo: citytow,
          towindex: e.detail.value,
          threeindex: 0
        })
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'success',
          duration: 2000,
        });
      }
    })
  },
  bindPickerChangethree(e) {
    var that = this;
    var inx = e.detail.value
    var citythree = this.data.CityThree[inx].Id
    if (citythree == 0) {
      return false;
    }
    that.setData({
      CityIdThree: citythree,
      threeindex: inx
    })
  },
 /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //提交表单
  reg: function (e) {
    var that = this;
    var Id = e.detail.value.Id;
    var Contacts = e.detail.value.Contacts;
    var ContactsTel = e.detail.value.ContactsTel;
    var AddressDetail = e.detail.value.AddressDetail;
    var CityIdOne = that.data.CityIdOne;
    var CityIdTwo = that.data.CityIdTwo;
    var CityIdThree = that.data.CityIdThree;
    var IsDefault = that.data.IsDefault;
    if (Contacts == '') {
      wx.showToast({
        title: '请输入姓名',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (ContactsTel == '') {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CityIdOne == '') {
      wx.showToast({
        title: '请选择所在省份',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CityIdTwo == '') {
      wx.showToast({
        title: '请选择所在城市',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (CityIdThree == '') {
      wx.showToast({
        title: '请选择所在地区',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (AddressDetail == '') {
      wx.showToast({
        title: '请输入详细地址',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    app.Post(api.wxapp.ChangeAddress, {
      Id: Id,
      CityIdOne: CityIdOne,
      CityIdTwo: CityIdTwo,
      CityIdThree: CityIdThree,
      AddressDetail: AddressDetail,
      Contacts: Contacts,
      ContactsTel: ContactsTel,
      IsDefault: IsDefault
    }, function (res) {
      console.log(res);
      if (res.Code == 200) {
        wx.navigateBack({
          delta: 1
        })
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },
  checkboxChange(e) {
    console.log(e)
    if (e.currentTarget.dataset.type == false) {
      this.setData({
        IsDefault: true
      })
    } else {
      this.setData({ 
        IsDefault: false
      })
    }
  },
 
    //删除订单 
  submitt: function (options) {
      var that = this;
    var addrsss_id = that.data.id
      wx.showModal({
        title: '提示',
        content: '您确定删除地址吗',
        success(res) {
          if (res.confirm) {
            app.Get(api.wxapp.DeleteAddress, {
              userAddressId: addrsss_id
            }, function (res) {
              if (res.Code == 200) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'success',
                  duration: 2000,
                  success: function () {
                    wx.navigateTo({
                      url: '/pages/xuanzedz/xuanzedz',
                    })
                  }
                })
              }
              else {
                var msg = res.Msg
                wx.showToast({
                  title: msg,
                  icon: 'none',
                  duration: 2000,
                });
              }
            })
          } else if (res.cancel) {

          }
        }
      })
    }
  
})