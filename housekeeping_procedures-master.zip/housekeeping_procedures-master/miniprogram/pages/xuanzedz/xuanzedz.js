var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
          list:[   
          ],
    addresslist:[

    ],
  },
  get_about: function (state) {
    var that = this
    wx.showLoading({
      title: '加载中',
    })
  },
  tiao:function(){
    wx.redirectTo({
      url: '/pages/dizhi/dizhi',
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.get_about('');
    app.Get(api.wxapp.UserAddress, {
    }, function (res) {
      if (res.Code == 200) {
        console.log(res)
        that.setData({
          addresslist: res.Data,
        })
        wx.hideLoading()
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },
  //checkbox改变事件
  checkboxChange: function (e) {
    var that = this;
    var id = e.detail.value;
    app.Get(api.wxapp.ChangeAddressIsDefault, {
      id: id
    }, function (res) {
      if (res.Code == 200) {
        wx.navigateTo({
          url: '/pages/tijiaodd/tijiaodd',
        })
      }
      else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  }
})