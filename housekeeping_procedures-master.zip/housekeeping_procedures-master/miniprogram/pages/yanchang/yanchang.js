var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    total: [{
      total: 0
    }, ],
    price: 0,
    OrderId: '',
    Count: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    var id = options.id;

    app.Get(api.wxapp.RenewOrderDetail, {
      id: id,

    }, function (res) {
      console.log(111);
      console.log(res);
      console.log(222);
      if (res.Code == 200) {
        var list = res.Data.List;
        var datas = [];
        var price = that.data.price;
        for (var i = 0; i <= list.length - 1; i++) {
          var obj = {};
          obj.CommodityImg = list[i]['CommodityImg'];
          obj.CommodityName = list[i]['CommodityName'];
          obj.CommodityPrice = list[i]['CommodityPrice'];
          obj.CommoditySubName = list[i]['CommoditySubName'];
          obj.CommodityType = list[i]['CommodityType'];
          obj.CommodityUnit = list[i]['CommodityUnit'];
          obj.OrderDetailId = list[i]['OrderDetailId'];
          obj.UnitName = list[i]['UnitName'];
          obj.Unit = list[i]['CommodityUnit'];
          obj.Number = 1; //初始个数
          price = parseFloat(parseFloat(price) + parseFloat(list[i]['CommodityPrice'] * list[i]['CommodityUnit'])) * obj.Number;
          console.log(price);
          datas.push(obj);
        }
        that.setData({
          list: datas,
          price: price,
          OrderId: res.Data.OrderId
        })
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //数量添加
  bindPlus(e) {
    var that = this;
    var id = e.target.dataset.index; //获取是哪个订单的
    var number = e.target.dataset.number; //获取数量的
    var add_number = parseInt(number + 1);
    console.log(add_number)
    that.change_price(id, add_number);
  },
  //数量减少
  bindMinus(e) {
    var that = this;
    var id = e.target.dataset.index; //获取是哪个订单的
    var number = e.target.dataset.number; //获取数量的
    var add_number = parseInt(number - 1);
    if (add_number < 0) {
      return false;
    }
    console.log(add_number)
    that.change_price(id, add_number);
  },
  //更改价格和单位数量
  change_price(id, add_number) {
    console.log()
    var that = this;
    var list = that.data.list;
    var price = 0;
    var datas = [];
    for (var i = 0; i <= list.length - 1; i++) {

      var obj = {};
      if (list[i]['OrderDetailId'] == id) {

        obj.Number = add_number;
        obj.CommodityUnit = list[i]['Unit'] * add_number;
      } else {
        obj.CommodityUnit = list[i]['CommodityUnit'];
        obj.Number = list[i]['Number'];
      }
      obj.CommodityImg = list[i]['CommodityImg'];
      obj.Unit = list[i]['Unit'];
      obj.CommodityName = list[i]['CommodityName'];
      obj.CommodityPrice = list[i]['CommodityPrice'];
      obj.CommoditySubName = list[i]['CommoditySubName'];
      obj.CommodityType = list[i]['CommodityType'];
      obj.OrderDetailId = list[i]['OrderDetailId'];
      obj.UnitName = list[i]['UnitName'];
      price = parseFloat(parseFloat(price) + parseFloat(list[i]['CommodityPrice'] * obj.CommodityUnit));

      datas.push(obj);
    }
    console.log(datas);
    that.setData({
      list: datas,
      price: price
    })
  },
  //提交订单
  submit: function() {
    var that = this;
    var Money = that.data.Money;
    var OrderId = that.data.OrderId;
    var List = that.data.List; 
    if (OrderId == '') {
      wx.showToast({
        title: '请添加订单',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    var data = {};
    data.Money = that.data.price;
    data.OrderId = OrderId;
    data.Type = 2;
    //获取需要的订单信息
    var order_data = that.data.list;
    var list = [];
    for(var i=0;i<order_data.length;i++){
      var get_data = {};
      get_data.OrderDetailId = order_data[i]['OrderDetailId'];
      get_data.Count = order_data[i]['CommodityUnit'];
      list.push(get_data);
    }
    data.List = list;
    app.Post(api.wxapp.RenewOrderOne, data, function (res) {
      console.log('创建订单---------------')
      if (res.Code == 200) {
        wx.requestPayment({
          'timeStamp': res.Data.timeStamp,
          'nonceStr': res.Data.nonceStr,
          'package': res.Data.package,
          'signType': res.Data.signType,
          'paySign': res.Data.paySign,
          success: function(ress) {
            if (ress.errMsg == 'requestPayment:fail cancel') {
              wx.showModal({
                content: JSON.stringify(ress),
              });
            } else {
              wx.showToast({
                title: '付款成功',
                icon: 'success',
                duration: 2000,
                success: function() {
                  wx.redirectTo({
                    url: '/pages/mydingdan/mydingdan'
                  })
                }
              });
            }
          },
          fail: function(res) {
            wx.redirectTo({
              url: '/pages/mydingdan/mydingdan'
            })
          },
          complete: function(res) {
            // wx.switchTab({
            //   url: '/pages/personalCentre/personalCentre'
            // })
          }
        })
      } else {
        var msg = res.Msg
        wx.showToast({
          title: msg,
          icon: 'none',
          duration: 2000,
        });
      }

    })
  },
 
})