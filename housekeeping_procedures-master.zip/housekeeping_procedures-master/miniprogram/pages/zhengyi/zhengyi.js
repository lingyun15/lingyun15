var api = require('../../untils/util.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    maxTextLen: 11,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  get_postdispute: function(state) {
    var that = this
    wx.showLoading({
      title: '加载中',
    })
  },
  formSubmit: function(e) {
    var that = this;
    that.get_postdispute('')
    var RealName = e.detail.value.RealName;
    var OrderNumber = e.detail.value.OrderNumber;
    var Content = e.detail.value.Content;
    var ContactTel = e.detail.value.ContactTel;
    if (RealName == '') {
      wx.showToast({
        title: '请输入姓名',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (ContactTel == '') {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (OrderNumber == '') {
      wx.showToast({
        title: '请输入订单编号',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    if (Content == '') {
      wx.showToast({
        title: '请输入争议内容',
        icon: 'none',
        duration: 2000,
        mask: true
      })
      return false;
    }
    app.Post(api.wxapp.PostDispute, {
      RealName: RealName,
      OrderNumber: OrderNumber,
      Content: Content,
      ContactTel: ContactTel,
      OpenId: wx.getStorageSync("UserOpenId")
    }, function(res) {
      // console.log(res.Data.Token);return;
      if (res.Code == 200) {
        var toke = res.Data.Token
        wx.setStorageSync('userToken', toke);
        wx.reLaunch({
          url: '/pages/login/login'
        })
        wx.hideLoading()
      } else {
        wx.showToast({
          title: res.Msg,
          icon: 'none',
          duration: 2000,
        });
      }

    })
  }
})