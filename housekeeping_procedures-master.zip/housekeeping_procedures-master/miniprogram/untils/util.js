
//接口地址recycle,,,,,sdsdfsd
//var on_line = "http://localhost:8805/api"; //本地
//var on_line = "http://39.105.23.31/api"; 
var site = "https://hackwork.oss-cn-shanghai.aliyuncs.com/lesson/weapp/4/weapp.jpg";
var on_line = ""; //正式
//var on_line = "http://47.105.41.175:8090/api" //测试
module.exports = {
  wxapp: {
    //获取openid
    LoginByCode: on_line + '/User/LoginByCode',
    GetUserInfo: on_line + '/User/GetUserInfo',//获取用户信息
    Register: on_line + '/User/Register',//用户注册
    GetIsRegiste: on_line + '/User/GetIsRegiste',//判断用户是否存在
    Login: on_line + '/User/Login',//登陆
    Sms: on_line + '/User/Sms',//发短信
    UserReset: on_line + '/User/UserReset',//忘记密码
    ChangeUserImg: on_line + '/User/ChangeUserImg',//更新用户头像
    UploadFileNew: site + '/UploadFileNew',//图片上传
    ChangeUserReal: on_line + '/User/ChangeUserReal',//实名认证
    GetAbout: on_line + '/User/GetAbout',//获取关于我们/客服中心
    GetChangeUserReal: on_line + '/User/GetChangeUserReal', //获取实名认证
    PostDispute: on_line + '/User/PostDispute', //争议处理
    UserAddress: on_line + '/User/UserAddress',//获取地址列表
    ChangeAddress: on_line + '/User/ChangeAddress',//添加或更新地址
    GetProvince: on_line + '/User/GetProvince',//省的展示
    GetCityByProvinceId: on_line + '/User/GetCityByProvinceId',//根据省ID的展示市
    GetAreaByCityId: on_line + '/User/GetAreaByCityId',//根据市ID的展示区域
    GetCommoditySeries: on_line + '/User/GetCommoditySeries',//获取服务系列
    GetCommodityType: on_line + '/User/GetCommodityType',//获取服务系列详情
    GetCommodity: on_line + '/User/GetCommodity',//获取服务套餐列表
    AddShopCart: on_line + '/User/AddShopCart',//加入购物车
    GetShopCart: on_line + '/User/GetShopCart',//获取购物车列表
    CreatOrder: on_line + '/Order/CreatOrder',//购物车创建订单
    OrderDetail: on_line + '/User/OrderDetail',//订单详情
    OrderShop: on_line + '/User/OrderShop',//创建订单展现
    GetUserAddress: on_line + '/User/GetUserAddress',//根据id获取地址
    ChangeUserTel: on_line + '/User/ChangeUserTel',//换绑手机号
    OrderList: on_line + '/User/OrderList',//订单列表
    CreatOrderOne: on_line + '/Order/CreatOrderOne',//订单列表待支付订单支付
    DetateOrder: on_line + '/User/DetateOrder',//订单删除
    RenewOrderDetail: on_line + '/User/RenewOrderDetail',//订单延长页面展现
    GetEvaluatemplate: on_line + '/User/GetEvaluatemplate',//评价模板
    PostEvaluate: on_line + '/User/PostEvaluate',//提交评价
    RenewOrderOne: on_line + '/Order/RenewOrderOne',//延长服务
    ChangeOrderState: on_line + '/User/ChangeOrderState',//验收服务
    GetCityName: on_line + '/User/GetCityName',  //根据经纬度获取城市
    GetShopList: on_line + '/User/GetShopList', //根据城市名获取商家列表
    DeleteAddress: on_line + '/User/DeleteAddress', //删除地址
    ChangeAddressIsDefault: on_line + '/User/ChangeAddressIsDefault',//设置默认地址
  }
}