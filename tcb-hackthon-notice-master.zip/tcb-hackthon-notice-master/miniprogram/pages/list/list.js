// pages/list/list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [
      'https://lingyuncity.oss-cn-hangzhou.aliyuncs.com/mmexport1635645571106.jpg',
      'https://lingyuncity.oss-cn-hangzhou.aliyuncs.com/mmexport1635645574129.jpg',
      'https://lingyuncity.oss-cn-hangzhou.aliyuncs.com/mmexport1635645578967.jpg'
    ],
    interval: 5000,
    duration: 1000,
    indicatorDots: true,
    indicatorColor: "#ffffff",
    activecolor:"#2971f6",
    autoplay: true,
    xueyuan:[
      {
        name:"成都流云装饰",
        img:"/images/xueyuan2.jpg",
        desc:"简介：公司以高质量、高效管理、创新型体验为基准。 房屋建筑行业化施工，人工、材料透明化定价，工艺标准透明标准化管理；以实现建筑行业的公开公平公正原则。",
        xueyuanid: "88885"
      },
      {
        name:"设计部",
        img:"/images/xueyuan1.jpg",
        desc:"公司长期寻觅优秀设计师的加入、现有设计总监、设计部经理和精品设计师三个档次。拥有美式乡村风格、古典欧式风格、地中海式风格、东南亚风格、日式风格、新古典风格、现代简约风格、新中式风格（古典中式风格）；八大设计风格，欢迎前来咨询",
        xueyuanid:"88888",
      },
      {
        name:"工程部",
        img:"/images/xueyuan4.jpg",
        desc:"公司现有自营和外包两种方式，以达到质量、安全和成本的最优化。也分为自营优秀团队、外包合作优秀团队和精品外包班组三个档次以满足客户的各方要求，欢迎前来咨询。",
        xueyuanid:"88887",
      },
      {
        name:"成本部",
        img:"/images/xueyuan3.jpg",
        desc:"公司现根据市面材料和人工的波动，实时的通知涨幅；以保障价位的合理性，来实现公司的公平、公正、公开性的初衷。",
        xueyuanid:"88886"
      },
      {
        name:"软件部",
        img:"/images/xueyuan5.jpg",
        desc:"公司有软件设计团队，来设计网页、APP和小程序的开发。如果有需要的朋友，价格优惠合理，欢迎前来咨询。",
        xueyuanid:"88887"
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})