// pages/me/me.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    menuitems: [
      // { text: '我的收藏', url: '../userinfo/userinfo', icon: '', tips: '' },
      { text: '历史发布', url: '/pages/mytongzhi/mytongzhi', icon: '/images/fabu.png', tips: '' },
      { text: "关于成都流云", url: '/pages/banben/banben', icon: '/images/aboutus.png', tips: '' },
      
    ],
      userinfo:{},
      openid:""
  },
    onGotUserInfo:function(e){
      const that = this
      console.log("获取用户信息成功：",e.detail.userInfo)
      wx.cloud.callFunction({
        name:"login",
        success:res=>{
          console.log("云函数调用成功：",res.result)
          that.setData({
            openid:res.result.openid,
            userinfo:e.detail.userInfo
          })
          that.data.userinfo.openid = that.data.openid
          console.log(that.data.userinfo)
          wx.setStorageSync("userinfo", that.data.userinfo)
        },
        fail:res=>{
          console.log("云函数调用失败")
        }
      })
    },

    gotopage: function(){
      wx.redirectTo({
        url: '/pages/shangchuan/shangchuan', 
      })

 
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const yonghu = wx.getStorageSync('userinfo')
    this.setData({
      userinfo:yonghu,
      openid:yonghu.openid
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})