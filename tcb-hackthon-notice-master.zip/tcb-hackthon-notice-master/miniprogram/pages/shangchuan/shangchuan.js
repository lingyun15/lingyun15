// pages/shangchuan/shangchuan.js
const yhsc = {
  date:"0",
  desc:"0",
  fileid:"0",
  img:"0",
  name:"0",
  xueyuan:"0",
  xueyuanid:"0",
  xueyuanimg:"0"
};
const note = 1




Page({

  /**
   * 页面的初始数据
   */
  data: {
    filename:"",
    coverImage:"",
    pickerdate:"发布时间",
    openid:""
  },

  bindDateChange: function (e) {
    const val = e.detail.value
    this.setData({
      pickerdate:val
    })
  },

  async checkUser() {
    const db = wx.cloud.database()  //获取数据库的引用
const _ = db.command 
    //获取clouddisk是否有当前用户的数据，注意这里默认带了一个where({_openid:"当前用户的openid"})的条件
    const userData = await db.collection('clouddisk').get() 
    console.log("当前用户的数据对象",userData)
 
    //如果当前用户的数据data数组的长度为0，说明数据库里没有当前用户的数据
    if(userData.data.length === 0){      
      //没有当前用户的数据，那就新建一个数据框架，其中_id和_openid会自动生成
      return await db.collection('clouddisk').add({
        data:{
          //nickName和avatarUrl可以通过getUserInfo来获取，这里不多介绍
          "nickName": "", 
          "avatarUrl": "",
          "albums": [ ],
          "folders": [ ]
        }
      })
    }else{
      this.setData({
        userData
      })
      console.log('用户数据',userData)
    }
  },

/*带上传*/
tupian(){
  wx.chooseImage({
    count: 1,
    success: res => {
      console.log('选择文件之后的res',res)
      const filePath = res.tempFilePaths[0]
      this.setData({
        coverImage: filePath
      })
      const cloudPath = `tongzhitupian/${Date.now()}-${Math.floor(Math.random(0, 1) * 1000)}` + filePath.match(/\.[^.]+?$/)
      wx.cloud.uploadFile({
        cloudPath: cloudPath,
        filePath: filePath,
        success: res => {
          console.log('上传成功', res)
          yhsc.img = res.fileID
        },
      })
    }
  })
},

/*带上传*/
  chooseMessageFile(){
    let that = this
    wx.chooseMessageFile({
      count: 1,
      success: res => {
        console.log('选择文件之后的res',res)
        const filePath = res.tempFiles[0].path
        const cloudPath = `tongzhiwenjian/${Date.now()}-${Math.floor(Math.random(0, 1) * 1000)}` + filePath.match(/\.[^.]+?$/)
        const book = res.tempFiles[0].name
        wx.cloud.uploadFile({   
          cloudPath,filePath
        }).then(res => {
          console.log(res)
          yhsc.fileid = res.fileID
          that.setData({
            filename:book + "上传成功"
          })   
        })      
        .catch(error => {
          console.log("文件上传失败",error)
        })
      }
    })
  },

  fromsubmit(e) {
    const db = wx.cloud.database()  //获取数据库的引用
    const _ = db.command 
    console.log(e)
    const id = e.detail.value.xueyuanid
    console.log(id)
    yhsc.date = e.detail.value.date
    yhsc.desc = e.detail.value.content
    yhsc.name = e.detail.value.title
    yhsc.xueyuanimg = "/images/xueyuanimg.jpg"
    yhsc.xueyuanid = e.detail.value.xueyuanid
    for(let key in yhsc){
      if(!yhsc[key]){
        wx.showToast({
          title: '请填写完整信息',
          duration: 2000
        })
        note = 0
        wx.redirectTo({
          url: '/pages/shangchuan/shangchuan',
        })
      }
    }
    if(note === 1){
      if(id === "88888"){
        yhsc.xueyuan = "设计部"
        yhsc.xueyuanid = id
      }else if(id === "88884"){
        yhsc.xueyuan = "工程部"
        yhsc.xueyuanid = id
      }else if(id === "88885"){
        yhsc.xueyuan = "成本部"
        yhsc.xueyuanid = id
      }else if(id === "88886"){
        yhsc.xueyuan = "软件部"
        yhsc.xueyuanid = id
      }else if(id === "88887"){
        yhsc.xueyuan = "招商部"
        yhsc.xueyuanid = id
      }else{
        wx.showToast({
          title: '无权限',
        })
        note = 0
        setTimeout(function () {
          wx.switchTab({
            url: '/pages/me/me',
          })
         }, 500)
      }
    }
    if(note === 1){
      db.collection('tongzhi').add({
        data: {
          date:yhsc.date,
          desc:yhsc.desc,
          fileid:yhsc.fileid,
          img:yhsc.img,
          name:yhsc.name,
          xueyuan:yhsc.xueyuan,
          xueyuanid:yhsc.xueyuanid,
          xueyuanimg:yhsc.xueyuanimg
        },
        success: function(res) {
          // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
          console.log(res)
          wx.showToast({
            title: '发布成功',
            icon: 'success',
            duration: 2000
          })
          setTimeout(function () {
            wx.switchTab({
              url: '/pages/me/me',
            })
           }, 500)
        }
      })
    }
    
  },




  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const yonghu = wx.getStorageSync('userinfo')
    let that = this
    that.setData({
      openid:yonghu.openid
    })
    this.checkUser()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})