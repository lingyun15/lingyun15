// pages/tonzhi/tonzhi.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
        xueyuan: "",
        xueyuanimg:"",
        date:"",
        name:"",
        img:"",
        desc:"",
        fenlei:"",
        fileid:"",
        xueyuanid:"",
        shoucang:0,
        openid:"",
        shoucanglist:""
  },

  async checkUser() {
    const db = wx.cloud.database()  //获取数据库的引用
    const _ = db.command 
    //获取clouddisk是否有当前用户的数据，注意这里默认带了一个where({_openid:"当前用户的openid"})的条件
    const userData = await db.collection('shoucang').get() 
    console.log("当前用户的收藏",userData)
 
    //如果当前用户的数据data数组的长度为0，说明数据库里没有当前用户的数据
    if(userData.data.length === 0){      
      //没有当前用户的数据，那就新建一个数据框架，其中_id和_openid会自动生成
      return await db.collection('shoucang').add({
        data:{
          
          "name":[],
        }
      })
    }else{
      this.setData({
        userData
      })
      console.log('用户数据',userData)
    }
  },

  changeshoucang:function(e){
    const wenzhang = wx.getStorageSync('book')
    const change = {}
    console.log(wenzhang)
    if(this.data.shoucang === 0){
      this.setData({
        shoucang:1
      })
      console.log(this.data.shoucang)
      const bookname = this.data.name
      console.log(bookname)
      change[bookname] = this.data.shoucang
      Object.assign(change,wenzhang)
      console.log(change)
      wx.setStorageSync("wenzhang", change)
    }else{


    }
  },

  downloadFile(){
    wx.cloud.downloadFile({
      fileID: this.data.fileid
    }).then(res => {
        const filePath = res.tempFilePath
        console.log(filePath)
        wx.openDocument({
          filePath: filePath
        })
    }).catch(error => {
      console.log(error)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  console.log(options)
  this.setData({
    xueyuan:options.xueyuan,
    xueyuanimg:options.xueyuanimg,
    date:options.date,
    name:options.name,
    img:options.img,
    desc:options.desc,
    fileid:options.fileid,
    xueyuanid:options.xueyuanid,
    
  })
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})